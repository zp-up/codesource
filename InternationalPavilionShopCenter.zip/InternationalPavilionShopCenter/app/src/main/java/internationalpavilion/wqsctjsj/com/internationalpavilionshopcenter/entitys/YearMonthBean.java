package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys;

import com.bigkoo.pickerview.model.IPickerViewData;

import java.util.ArrayList;

/**
 * Created by wuqaing on 2018/12/5.
 */

public class YearMonthBean implements IPickerViewData {
    @Override
    public String getPickerViewText() {
        return null;
    }
}
