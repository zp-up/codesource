package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.wxapi;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;


/**
 * Created by wuqaing on 2018/8/28.
 */

public class WXEntryActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
