package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.models.modelsInterface;

import org.xutils.http.RequestParams;

/**
 * Created by wuqaing on 2018/12/14.
 */

public interface NetRequestInterface {
    void doNetRequest(RequestParams params,NetCallBack callBack);
}
