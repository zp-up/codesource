/**
  * Copyright 2018 bejson.com 
  */
package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys.goodsDetailBean;

/**
 * Auto-generated: 2018-12-21 9:48:29
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Speclist {
    private boolean isChecked;
    private int id;
    private boolean index;
    private int goods_goods;
    private String spec;

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

    public boolean isChecked() {

        return isChecked;
    }

    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

    public void setIndex(boolean index) {
         this.index = index;
     }
     public boolean getIndex() {
         return index;
     }

    public void setGoods_goods(int goods_goods) {
         this.goods_goods = goods_goods;
     }
     public int getGoods_goods() {
         return goods_goods;
     }

    public void setSpec(String spec) {
         this.spec = spec;
     }
     public String getSpec() {
         return spec;
     }

}