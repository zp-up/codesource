/**
  * Copyright 2018 bejson.com 
  */
package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys.goodsDetailBean;
import java.util.List;

/**
 * Auto-generated: 2018-12-21 13:46:43
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Goods_brand {

    private String name;
    private String en;
    private int id;
    private List<String> logo;
    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setEn(String en) {
         this.en = en;
     }
     public String getEn() {
         return en;
     }

    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

    public void setLogo(List<String> logo) {
         this.logo = logo;
     }
     public List<String> getLogo() {
         return logo;
     }

}