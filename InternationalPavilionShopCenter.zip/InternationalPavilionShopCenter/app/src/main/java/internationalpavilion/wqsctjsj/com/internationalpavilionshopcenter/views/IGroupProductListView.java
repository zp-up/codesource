package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.views;

/**
 * Author:chris - jason
 * Date:2019/2/19.
 * Package:internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.views
 */
//拼团商品列表 v
public interface IGroupProductListView {
}
