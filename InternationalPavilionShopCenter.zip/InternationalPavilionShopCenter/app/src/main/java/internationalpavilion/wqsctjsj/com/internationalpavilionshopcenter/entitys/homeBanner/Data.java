/**
  * Copyright 2018 bejson.com 
  */
package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys.homeBanner;
import java.util.List;

/**
 * Auto-generated: 2018-12-17 16:47:53
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Data {

    private int id;
    private String name;
    private int app_app;
    private List<String> img;
    private String type;
    private String url;
    private String color;
    private String pages;
    private String content;
    private String text;
    private int sort;
    private int status;
    private String update_time;
    private String create_time;
    private String error;
    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setApp_app(int app_app) {
         this.app_app = app_app;
     }
     public int getApp_app() {
         return app_app;
     }

    public void setImg(List<String> img) {
         this.img = img;
     }
     public List<String> getImg() {
         return img;
     }

    public void setType(String type) {
         this.type = type;
     }
     public String getType() {
         return type;
     }

    public void setUrl(String url) {
         this.url = url;
     }
     public String getUrl() {
         return url;
     }

    public void setColor(String color) {
         this.color = color;
     }
     public String getColor() {
         return color;
     }


    public void setPages(String pages) {
         this.pages = pages;
     }
     public String getPages() {
         return pages;
     }

    public void setContent(String content) {
         this.content = content;
     }
     public String getContent() {
         return content;
     }

    public void setText(String text) {
         this.text = text;
     }
     public String getText() {
         return text;
     }

    public void setSort(int sort) {
         this.sort = sort;
     }
     public int getSort() {
         return sort;
     }

    public void setStatus(int status) {
         this.status = status;
     }
     public int getStatus() {
         return status;
     }

    public void setUpdate_time(String update_time) {
         this.update_time = update_time;
     }
     public String getUpdate_time() {
         return update_time;
     }

    public void setCreate_time(String create_time) {
         this.create_time = create_time;
     }
     public String getCreate_time() {
         return create_time;
     }

    public void setError(String error) {
         this.error = error;
     }
     public String getError() {
         return error;
     }

}