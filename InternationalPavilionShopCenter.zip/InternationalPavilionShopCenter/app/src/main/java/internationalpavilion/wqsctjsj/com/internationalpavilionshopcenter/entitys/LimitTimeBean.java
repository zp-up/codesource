package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys;

/**
 * Created by wuqaing on 2018/12/7.
 */

public class LimitTimeBean {
    private int id;
    private String goodsName;
    private double price;
    private long startTime;
    private long endTime;
    private String storeName;
    private String storeType;
    private String spec;
    private double pron_price;

    public double getPron_price() {
        return pron_price;
    }

    public void setPron_price(double pron_price) {

        this.pron_price = pron_price;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public void setStoreType(String storeType) {
        this.storeType = storeType;
    }

    public void setSpec(String spec) {
        this.spec = spec;
    }

    public String getStoreName() {

        return storeName;
    }

    public String getStoreType() {
        return storeType;
    }

    public String getSpec() {
        return spec;
    }

    public void setEndHour(int endHour) {
        this.endHour = endHour;
    }

    public int getEndHour() {

        return endHour;
    }

    private int endHour;

    public void setGoodsImg(String goodsImg) {
        this.goodsImg = goodsImg;
    }

    public String getGoodsImg() {

        return goodsImg;
    }

    private String goodsImg;

    public void setId(int id) {
        this.id = id;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public int getId() {

        return id;
    }

    public String getGoodsName() {
        return goodsName;
    }

    public double getPrice() {
        return price;
    }

    public long getStartTime() {
        return startTime;
    }

    public long getEndTime() {
        return endTime;
    }
}
