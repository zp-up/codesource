package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.widget.flowtaglayout;

/**
 * Created by HanHailong on 16/6/26.
 */

public interface OnInitSelectedPosition {
    boolean isSelectedPosition(int position);
}
