package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys;

/**
 * Created by wuqaing on 2018/12/12.
 */

public class LogisticsBean {
    public String acceptStation;
    public String acceptTime;
}
