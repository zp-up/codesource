/**
  * Copyright 2018 bejson.com 
  */
package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys.goodsDetailBean;

/**
 * Auto-generated: 2018-12-21 9:48:29
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Goods_cate {

    private String name;
    private int id;
    public void setName(String name) {
         this.name = name;
     }
     public String getName() {
         return name;
     }

    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

}