/**
  * Copyright 2018 bejson.com 
  */
package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.entitys.goodsDetailBean;

/**
 * Auto-generated: 2018-12-21 9:48:29
 *
 * @author bejson.com (i@bejson.com)
 * @website http://www.bejson.com/java2pojo/
 */
public class Customs_hs {

    private String hs_code;
    private int tax_rate;
    private int post_rate;
    private int id;
    public void setHs_code(String hs_code) {
         this.hs_code = hs_code;
     }
     public String getHs_code() {
         return hs_code;
     }

    public void setTax_rate(int tax_rate) {
         this.tax_rate = tax_rate;
     }
     public int getTax_rate() {
         return tax_rate;
     }

    public void setPost_rate(int post_rate) {
         this.post_rate = post_rate;
     }
     public int getPost_rate() {
         return post_rate;
     }

    public void setId(int id) {
         this.id = id;
     }
     public int getId() {
         return id;
     }

}