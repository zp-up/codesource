package internationalpavilion.wqsctjsj.com.internationalpavilionshopcenter.widget.flowtaglayout;

import android.view.View;

/**
 * Created by HanHailong on 15/10/20.
 */
public interface OnTagClickListener {
    void onItemClick(FlowTagLayout parent, View view, int position);
}
